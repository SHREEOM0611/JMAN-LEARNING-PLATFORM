{{
    config(
        tags=['mart']
    )
}}
WITH
registrations AS (
    SELECT
        *
    FROM {{ ref('registrations') }}
),

event AS (
    SELECT
     *
    FROM {{ref('event')}}
),

registration_details AS (
    SELECT r.eventr_id, e.name,e.date, e.capacity,r.userr_id FROM event as e 
    JOIN registrations as r
    on r.eventr_id=e.event_id
),

count_event AS (
    SELECT  eventr_id, name, count(userr_id) as total_registered, capacity from registration_details
    group by eventr_id, name, capacity
),

percentage_event AS (
    SELECT eventr_id, name, ROUND((total_registered/capacity)*100,2) as registration_percentage 
    FROM count_event
)


select * from percentage_event
 