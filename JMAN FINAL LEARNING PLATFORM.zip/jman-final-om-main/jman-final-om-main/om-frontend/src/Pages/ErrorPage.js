// ErrorComponent.js

import React from "react";
import "./AdminPage/admin.css";

const ErrorComponent = () => {
  return (
    <div>
      <h1 className="admin-page-heading">Error: Page Not Found</h1>
    </div>
  );
};

export default ErrorComponent;
